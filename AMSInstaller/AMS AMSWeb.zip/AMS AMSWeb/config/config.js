var config = {
  //Conexion a la DB MYSQL
  VigenciaToken: 0, //minutos
  cacheConfig: {
    tokenExpires: 24, //Tiempo en horas minutos que expiran los tokens
    tokenExpiresTTL: 60,
    checkTokens: 300, //300, //Intervalo en el que se verifican los tokens vencidos para limpiar
  },
  // Configuración App Node
  ServerProtocol: "http", // protocolo: http | https
  ServerCert: "AMSuite.crt", // certificado.pem
  ServerCertKey: "AMSuite.key", // llave del certificado
  ServerIP: "10.12.10.40", // Ip o DNS del host
  ServerPort: 12000, // Puerto en el que publica Node
  WorkerId: 0,
  SessionVerify: false, // false: No controlo sessiones | true: Controlo sessiones
  AcceptOrigin: "*", //Acepta request de el siguiente origen
  RPCPort: 8189, //Puerto de Servidor Cache
  //Monitor Stats
  Monitor: true,
  MonitorWebPort: 8888,
  //Genera Logs
  Debug: true,
  //Traffic Log
  LogAccess: true,
};

module.exports = config;
