var createError = require("http-errors");
var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var cors = require("cors"); //Cors
var history = require("connect-history-api-fallback");
var indexRouter = require("./routes/index");
var usersRouter = require("./routes/users");
const bodyParser = require("body-parser");
var cacheServer = require("./app_modules/cacheServer");
var config = require("./config/config");
//require("./app_routes/ApiHandler")
// require("./app_routes/AMSuite/Session")

//set api ip
const xml2js = require("xml2js");
const parser = new xml2js.Parser({ attrkey: "ATTR" });
const fs = require("fs");
parser.parseString(
  fs.readFileSync("./client/build/AMSuiteConfig.xml", { encoding: "utf-8" }),
  function (error, result) {
    if (error === null) {
      cacheServer.set(
        "API_URL",
        result.ConfigParameters.ConfigParameter[1].ATTR.value
      );
      cacheServer.set(
        "SERVER_URL",
        result.ConfigParameters.ConfigParameter[0].ATTR.value
      );
    } else {
      console.log("error in configParameters ", error);
    }
  }
);
var app = express();

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

app.use(bodyParser.json());

recursiveRoutes("app_routes"); // Initialize it
function recursiveRoutes(folderName) {
  fs.readdirSync(folderName).forEach(function (file) {
    var fullName = path.join(folderName, file);
    var stat = fs.lstatSync(fullName);

    if (stat.isDirectory()) {
      recursiveRoutes(fullName);
    } else if (file.toLowerCase().indexOf(".js")) {
      const api = require("./" + fullName);
      Object.keys(api).map((k) => api[k](app));
    }
  });
}

var corsOptions = {
  origin: "*",
};
//Habilitar Cors
app.use(cors(corsOptions));

app.use(history());
// app.use(express.static(path.join(__dirname, "client/build")));
// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "client/build")));

app.use("/", indexRouter);
app.use("/users", usersRouter);

const port = process.env.PORT || config.ServerPort;
app.set("port", port);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

const axios = require("axios");

const apiAxios = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});
const socketIo = require("socket.io");
//

let server;
if (config.ServerProtocol === "http") {
  const http = require("http");
  server = http.createServer(app);
} else {
  const https = require("https");
  server = https.createServer(
    {
      key: fs.readFileSync(`./${config.ServerCertKey}`),
      cert: fs.readFileSync(`./${config.ServerCert}`),
    },
    app
  );
}

/* INIT SOCKETS */
let lastSuccessDatetime = new Date("1891", "9", "28");
let interval;
let intervalNotifications;
let intervalMessage;
let intervalLiveTracking;
let intervalUsersActive;
let intervalPanelsPositions;
let concurrentUsers = [];
let subscriptionReload = [];
let subscriptionPanelsPositions = [];
let messagesToSend = [];
let VisitsToApprove = undefined;
let sending = false;
// const server = http.createServer(app);
const io = socketIo(server);
io.on("connection", (socket) => {
  console.log("connection");
  socket.on("logIn", (id, token) => {
    let addUser = true;
    concurrentUsers.map((user) => {
      if (id === user.id && user.clientIP !== socket.handshake.address) {
        io.to(`${user.clientId}`).emit("logOut");
      } else if (id === user.id && user.clientIP === socket.handshake.address) {
        addUser = false;
        user.clientId.push(socket.client.id);
        console.log("concurrentUsers", concurrentUsers);
      }
    });
    if (addUser) {
      getMaxConcurrentUsers(socket).then((maxCurrentUser) => {
        let isValid =
          maxCurrentUser - concurrentUsers.length > 0 || maxCurrentUser === -1;
        if (isValid) {
          concurrentUsers.push({
            clientId: [socket.client.id],
            id: id,
            clientIP: socket.handshake.address,
            token: token,
          });
          if (!intervalUsersActive) {
            intervalUsersActive = setInterval(() => getUsersActive(), 2000);
          }
        }
        io.to(`${socket.client.id}`).emit("logInValid", {
          message: isValid,
        }); //Emitting a new message. It will be consumed by the client
      });
    }
  });

  socket.on("changes", () => {
    subscriptionReload.push(socket.client.id);
    if (!interval) interval = setInterval(() => getAnyChange(socket), 2000);
  });

  socket.on("messages", (message) => {
    messagesToSend.push(message);
  });

  socket.on("startMessagesSender", (token) => {
    //  if (messagesToSend.length > 0 && !sending)
    intervalMessage = setInterval(() => sendMessages(token), 2000);
  });

  socket.on("unsubscribeMessages", () => {
    if (intervalMessage) {
      clearInterval(intervalMessage);
      intervalMessage = undefined;
    }
  });

  socket.on("subscribeLiveTracking", (panelId, token) => {
    if (!intervalLiveTracking)
      intervalLiveTracking = setInterval(
        () => getPanelTracking(socket, panelId, token),
        2000
      );
  });

  socket.on("unsubscribeLiveTracking", () => {
    if (intervalLiveTracking) {
      clearInterval(intervalLiveTracking);
      intervalLiveTracking = undefined;
    }
  });

  socket.on("subscribeConnectedUsers", () => {
    if (!intervalLiveTracking)
      intervalLConnectedUsers = setInterval(() => getConnectedUsers(), 2000);
  });

  socket.on("unsubscribeConnectedUsers", () => {
    if (intervalLiveTracking) {
      clearInterval(intervalLiveTracking);
      intervalLiveTracking = undefined;
    }
  });

  socket.on("unsubscribeChanges", () => {
    if (subscriptionReload.length > 0)
      subscriptionReload = subscriptionReload.filter(
        (client) => client !== socket.client.id
      );
    if (subscriptionReload.length === 0) {
      if (interval) {
        clearInterval(interval);
        interval = undefined;
      }
    }
  });

  socket.on("subscriptionNotifications", (token) => {
    intervalNotifications = setInterval(
      () => getNotificationsVisitsToApprove(token, socket),
      5000
    );
  });

  socket.on("subscribePanelsPositions", (token) => {
    subscriptionPanelsPositions.push(socket.client.id);
    if (!intervalPanelsPositions)
      intervalPanelsPositions = setInterval(
        () => getPanelsPosition(token, socket),
        15000
      );
  });

  socket.on("unsubscribePanelsPositions", () => {
    if (subscriptionPanelsPositions.length > 0)
      subscriptionPanelsPositions = subscriptionPanelsPositions.filter(
        (client) => client !== socket.client.id
      );
    if (subscriptionPanelsPositions.length === 0) {
      if (intervalPanelsPositions) {
        clearInterval(intervalPanelsPositions);
        intervalPanelsPositions = undefined;
      }
    }
  });

  socket.on("disconnect", () => {
    console.log("disconnect");
    VisitsToApprove = undefined;
    subscriptionReload = subscriptionReload.filter(
      (client) => client !== socket.client.id
    );
    if (subscriptionReload.length === 0) {
      if (interval) {
        clearInterval(interval);
        interval = undefined;
      }
    }
    // if (subscriptionReload > 0) subscriptionReload = subscriptionReload - 1;
    if (
      concurrentUsers.filter(
        (data) =>
          data.clientId.some((client) => client === socket.client.id) &&
          data.clientId.length === 1
      ).length > 0
    ) {
      concurrentUsers = concurrentUsers.filter((data) =>
        data.clientId.some((client) => client !== socket.client.id)
      );

      if (concurrentUsers.length === 0) {
        if (interval) {
          clearInterval(interval);
          interval = undefined;
        }
        if (intervalUsersActive) {
          clearInterval(intervalUsersActive);
          intervalUsersActive = undefined;
        }
        if (intervalNotifications) {
          clearInterval(intervalNotifications);
        }
        if (intervalLiveTracking) {
          clearInterval(intervalLiveTracking);
          intervalLiveTracking = undefined;
        }
      }
    } else {
      concurrentUsers.map((user) => {
        if (user.clientId.some((client) => client !== socket.client.id)) {
          user.clientId = user.clientId.filter(
            (cli) => cli !== socket.client.id
          );
        }
      });
    }

    socket.disconnect();
  });
});

const getAnyChange = async (socket) => {
  try {
    const res = await apiAxios.get("/AMSuite/Sessions/ChangesFromDate", {
      params: { date: lastSuccessDatetime },
    }); // Getting the data from DarkSky
    // console.log("log de testing");
    if (res.data) {
      lastSuccessDatetime = new Date();
      io.emit("AnyChange", {
        message: res.data,
      }); // Emitting a new message. It will be consumed by the client
    }
  } catch (error) {
    console.error(`Error in getAnyChange: ${error}`);
  }
};

const getPanelsPosition = async (token, socket) => {
  try {
    const res = await apiAxios.get("/AccessControl/GPS/GetPanelsPosition", {
      params: {},
      headers: {
        Authorization: "Bearer " + token,
      },
    });
    if (res.data) {
      io.emit("panelsPositions", {
        message: res.data,
      });
      // io.to(`${client}`).emit("panelsPositions", {
      //   message: res.data,
      // });
    }
  } catch (error) {
    console.error(`Error in getPanelsPosition: ${error}`);
  }
};

const getNotificationsVisitsToApprove = async (token, socket) => {
  try {
    const res = await apiAxios.get("/AMSuite/Sessions/VisitsToApprove", {
      params: { onlyMyVisits: true },
      headers: {
        Authorization: "Bearer " + token,
      },
    }); // Getting the data from DarkSky

    if (VisitsToApprove !== res.data) {
      VisitsToApprove = res.data;
      concurrentUsers.map((user) => {
        if (user.token === token) {
          user.clientId.map((client) => {
            io.to(`${client}`).emit("AnyVisitsToApprove", {
              message: res.data,
            });
          });
        }
      });
    }
  } catch (error) {
    // console.error(`getNotificationsVisitsToApprove Error: ${error}`);
  }
};

const getMaxConcurrentUsers = async () => {
  try {
    const res = await apiAxios.get("/AMSuite/Sessions/GetMaxConcurrentUsers"); // Getting the data from DarkSky

    if (res.data) {
      if (res.data != -1) {
        return res.data;
      } else return -1;
    }
  } catch (error) {
    console.error(`Error in getMaxConcurrentUsers: ${error}`);
    return false;
  }
};

getConnectedUsers = async () => {
  try {
    const res = await apiAxios.get(
      "/AMSuite/Sessions/GetAllCurrentLoggedUserIds",
      {
        headers: {
          Authorization: "Bearer oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=",
        },
      }
    ); // Getting the data from DarkSky
    concurrentUsers.map((user) => {
      if (res.data) {
        io.to(`${user.clientId}`).emit("connectedUsers", {
          users: res.data,
        });
      }
    });
  } catch (error) {
    console.error(`Error in getConnectedUsers: ${error}`);
    return false;
  }
};

const getUsersActive = async () => {
  try {
    const res = await apiAxios.get(
      "/AMSuite/Sessions/GetAllCurrentLoggedUserIds",
      {
        headers: {
          Authorization: "Bearer oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=",
        },
      }
    ); // Getting the data from DarkSky
    concurrentUsers.map((user) => {
      if (res.data) {
        if (!res.data.find((dta) => dta === user.id)) {
          io.to(`${user.clientId}`).emit("connected", {
            users: res.data,
          });
        }
      }
    });
  } catch (error) {
    console.error(`Error in getMaxConcurrentUsers: ${error}`);
    return false;
  }
};

const getPanelTracking = async (socket, panelId, token) => {
  try {
    const res = await apiAxios.get("/AccessControl/Panels/LastGPSPosition", {
      params: { panelId: panelId },
      headers: {
        Authorization: "Bearer " + token,
      },
    }); // Getting the data from DarkSky
    concurrentUsers.map((user) => {
      user.clientId.map((client) => {
        io.to(`${client}`).emit("trackingPanel", {
          message: res.data,
        });
      });
    });
  } catch (error) {
    console.error(`Error in getPanelTracking: ${error}`);
    concurrentUsers.map((user) => {
      if (user.token === token) {
        user.clientId.map((client) => {
          io.to(`${client}`).emit("trackingPanel", {
            message: "",
          });
        });
      }
    });
    return false;
  }
};

const sendMessages = async (token, socket) => {
  let imSending = false;
  let apiError = false;
  while (messagesToSend.length > 0 && (!sending || imSending) && !apiError) {
    sending = true;
    imSending = true;

    try {
      const res = await apiAxios
        .post("/AccessControl/Devices/SendMessage", messagesToSend[0], {
          headers: {
            Authorization: "Bearer " + token,
          },
        })
        .catch((error) => {
          apiError = true;
        });
      if (res.data === true) {
        const message = messagesToSend.splice(0, 1);
        io.emit("MessageSended", {
          message: message[0],
        });
      }
    } catch (error) {
      console.log("error", error);
    }
  }
  if (imSending) sending = false;
};
/* FIN SOCKETS */

server.listen(port, function () {
  console.log("Started on port " + port);
});
