var NodeCache = require("node-cache");
var Cache = new NodeCache({ stdTTL: 0, checkperiod: 0 });

//Cache
let cacheServer = {
  cacheServer: function() {},

  get: function(key) {
    let value = Cache.get(key);
    return value;
  },
  set: function(key, value) {
    let success = Cache.set(key, value, 0);
    if (success) {
      return success;
    } else {
      return false;
    }
  },
  delKey: function(key) {
    return Cache.del(key);
  },
  all: function() {
    let mykeys = Cache.keys();
    return mykeys;
  }
};

Cache.on( "expired", function( key, value ){
  console.log("--------------EXPIRED CACHE-----------------", key, value)
});

module.exports = cacheServer;
