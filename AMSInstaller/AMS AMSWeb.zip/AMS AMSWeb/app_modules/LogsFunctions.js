const logErrors = (error, method) => {
  const { status, statusText } = error.response ? error.response : {};
  const { config } = error.response ? error.response : error;
  const data = error.response ? error.response.data : error.Error;

  console.log("\n");
  console.log(`${new Date(Date.now()).toLocaleString()}: ERROR EN ${method}`);
  console.log("_________________________");
  console.log("       Data Sent      ");
  console.log("    -----------------    ");
  console.log(`    url: ${config ? config.url : "Undefined"}`);
  console.log(`    method: ${config ? config.method : "Undefined"}`);
  console.log(`    data: ${config ? config.data : "Undefined"}`);
  console.log("    _________________________");
  console.log("      Data Received     ");
  console.log("    -----------------    ");
  console.log(`    status: ${status}`);
  console.log(`    status Text: ${statusText}`);
  console.log(`    data Error: ${data ? data.slice(0, 400) : "Undefined"}`);
};

const logErrorsWithOutData = (error, method) => {
  const { status, statusText } = error.response ? error.response : {};
  const { config } = error.response ? error.response : error;
  const data = error.response ? error.response.data : error.Error;
  
  console.log("\n");
  console.log(`${new Date(Date.now()).toLocaleString()}: ERROR EN ${method}`);
  console.log("_________________________");
  console.log("       Data Sent      ");
  console.log("    -----------------    ");
  console.log(`    url: ${config ? config.url : "Undefined"}`);
  console.log(`    method: ${config ? config.method : "Undefined"}`);
  console.log("    _________________________");
  console.log("      Data Received     ");
  console.log("    -----------------    ");
  console.log(`    status: ${status}`);
  console.log(`    status Text: ${statusText}`);
  console.log(`    data Error: ${data ? data.slice(0, 400) : "Undefined"}`);
};

module.exports = {
  logErrors,
  logErrorsWithOutData,
};
