const axios = require("axios");
const multer = require("multer");
const FormData = require("form-data");
var cacheServer = require("../../app_modules/cacheServer");

const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";
const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

var LogsFunctions = require("../../app_modules/LogsFunctions");

const sendTestEmail = (app) => {
  //Ruta publica
  app.post(
    "/api/AMSuite/Settings/TestEmailConfiguration",
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .post("/AMSuite/Settings/TestEmailConfiguration", data, config)
        .catch((error) => {
          console.log("error: ", error);
          // LogsFunctions.logErrors(error, "createCustomField");
          if (error.response)
            res.status(error.response.status).send({
              errorCode: error.response.status,
              errorText: error.response.statusText,
              errorData: error.response.data.slice(0, 400),
            });
          else res.status(500);
        });
      var cache = [];
      if (response) {
        res.setHeader("Content-Type", "application/json");
        res.json(response.data);
      }
    }
  );
};

const getSettings = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetSettings", async function (req, res, next) {
    let data = {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getSettings");
        if (error.response)
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        else res.status(500);
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    response.data &&
      cacheServer.set("urlLoginSAML", response.data.systemSettings.loginURL);

    res.json(response.data);
  });
};

const getAludocSettings = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetAludocSettings", async function (
    req,
    res,
    next
  ) {
    let data = {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetAludocSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getAludocSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editAludocSettings = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetAludocSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetAludocSettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editAludocSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getSystemSetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetSystem", async function (req, res, next) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetSystem", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getSystemSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editSystemSetting = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/System", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
        "Content-Type": "application/json",
      },
    };
    let response = await api
      .post("/AMSuite/Settings/System", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editSystemSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getEmployeeSetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetEmployeeSettings", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetEmployeeSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getEmployeeSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editEmployeeSetting = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/EmployeeSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/EmployeeSettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editEmployeeSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getEnterpriseSetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetEnterpriseSettings", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetEnterpriseSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getEnterpriseSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editEnterpriseSetting = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetEnterpriseSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetEnterpriseSettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editEnterpriseSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getNotifySetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetNotifySettings", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetNotifySettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getNotifySetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editNotifySetting = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetNotifySettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetNotifySettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editNotifySetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getMusteringSettings = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetMusteringSettings", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetMusteringSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getMusteringSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editMusteringSettings = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetMusteringSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetMusteringSettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editMusteringSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getVisitorSetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetVisitorSettings", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetVisitorSettings", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getVisitorSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editVisitorSetting = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetVisitorSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetVisitorSettings", data, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "editVisitorSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getLicense = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Licenses/Get", async function (req, res, next) {
    let config = {
      headers: {
        Authorization: req.headers["authorization"],
      },
    };
    let response = await api
      .get("/AMSuite/Licenses/Get", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getLicense");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const activeLicense = (app) => {
  //Ruta publica
  const upload = multer();

  app.post(
    "/api/AMSuite/Licenses/LoadFromStream",
    upload.any(),
    async function (req, res, next) {
      const formData = new FormData();
      const dataFile = req.files[0] ? req.files[0] : undefined;
      if (dataFile) {
        formData.append("file", dataFile.buffer, {
          filename: dataFile.originalname,
        });
      }
      const formHeaders = formData.getHeaders();
      let config = {
        params: {},
        headers: {
          ...formHeaders,
          Authorization: "Bearer " + TOKEN_ANONYMOUS,
        },
      };
      let response = await api
        .post("/AMSuite/Licenses/LoadFromStream", formData, config)
        .catch((error) => {
          LogsFunctions.logErrors(error, "activeLicense");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      if (response) {
        res.setHeader("Content-Type", "application/json");
        res.json(response.data);
      }
    }
  );
};

const updateTable = (app) => {
  //Ruta publica
  const upload = multer();
  const api2 = axios.create({
    baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
    timeout: 0,
  });
  app.post("/api/EasyAccess/Persons/UpdateCardholdersFromTSF", upload.any(), async function (
    req,
    res,
    next
  ) {
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();
    let config = {
      params: {},
      headers: {
        ...formHeaders,
        Authorization: req.headers.authorization
      },
    };
    let response = await api2
      .post(
        "/EasyAccess/Persons/UpdateCardholdersFromTSF",
        formData,
        config
      )
      .catch((error) => {
        LogsFunctions.logErrors(error, "activeLicense");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const checkLicense = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Licenses/CheckLicense", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Licenses/CheckLicense", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "checkLicense");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getToken = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Licenses/GetLicenseRequestKey", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/AMSuite/Licenses/GetLicenseRequestKey", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getToken");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const downloadToken = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Licenses/DownloadLicenseRequestFile", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Licenses/DownloadLicenseRequestFile", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "downloadToken");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const testActiveDirectoryDomain = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Sessions/TestActiveDirectoryDomain", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : {};
    let config = {
      params: currentdata,
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Sessions/TestActiveDirectoryDomain", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "testActiveDirectoryDomain");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getVersion = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetVersion", async function (req, res, next) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetVersion", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getVersion");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getLogoBannerSetting = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetLogoBanner", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetLogoBanner", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getLogoBannerSetting");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const saveLogo = (app) => {
  //Ruta publica
  const upload = multer();
  app.post(
    "/api/AMSuite/Settings/LogoBanner/:settingID",
    upload.any(),
    async function (req, res, next) {
      const settingID = req.params.settingID;
      const formData = new FormData();
      const dataFile = req.files[0] ? req.files[0] : undefined;
      if (dataFile) {
        formData.append("file", dataFile.buffer, {
          filename: dataFile.originalname,
        });
      }
      const formHeaders = formData.getHeaders();

      let config = {
        params: {},
        headers: {
          ...formHeaders,
          Authorization: "Bearer " + TOKEN_ANONYMOUS,
        },
      };

      let response = await api
        .post("/AMSuite/Settings/LogoBanner/" + settingID, formData, config)
        .catch((error) => {
          LogsFunctions.logErrors(error, "saveLogo");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      if (response) {
        res.setHeader("Content-Type", "application/json");
        res.json(response.data);
      }
    }
  );
};

const getAppLogo = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetAppLogo", async function (req, res, next) {
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let defaultData = await api
      .get("/AMSuite/Settings/GetAppLogo", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getAppLogo");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) {
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  });
};

const saveAppLogo = (app) => {
  //Ruta publica
  const upload = multer();
  app.post("/api/AMSuite/Settings/AppLogo/:id", upload.any(), async function (
    req,
    res,
    next
  ) {
    const id = req.params.id;
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();

    let config = {
      params: {},
      headers: {
        ...formHeaders,
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/AppLogo/" + id, formData, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "saveAppLogo");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const setNumericalRecordsSettings = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetNumericalRecordsSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetNumericalRecordsSettings", data, config)
      .catch((error) => {
        logErrors(error, "SetNumericalRecordsSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getNumericalRecordsSettings = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetNumericalRecordsSettings", async function (
    req,
    res,
    next
  ) {
    let data = "";
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };

    let response = await api
      .get("/AMSuite/Settings/GetNumericalRecordsSettings", config)
      .catch((error) => {
        logErrors(error, "GetNumericalRecordsSettings ");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getSettings,
  getEnterpriseSetting,
  editSystemSetting,
  getSystemSetting,
  getLogoBannerSetting,
  saveLogo,
  getEmployeeSetting,
  editEmployeeSetting,
  getVisitorSetting,
  editVisitorSetting,
  editEnterpriseSetting,
  getNotifySetting,
  editNotifySetting,
  editMusteringSettings,
  getMusteringSettings,
  getLicense,
  activeLicense,
  checkLicense,
  getToken,
  downloadToken,
  testActiveDirectoryDomain,
  saveAppLogo,
  getAppLogo,
  getAludocSettings,
  editAludocSettings,
  getVersion,
  sendTestEmail,
  getNumericalRecordsSettings,
  setNumericalRecordsSettings,
  updateTable,
};
