const axios = require("axios");
const multer = require("multer");
var cacheServer = require("../../app_modules/cacheServer");

const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getEasyAccessSettings = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Settings/GetEasyAccessSettings", async function (
    req,
    res,
    next
  ) {
    let data = {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Settings/GetEasyAccessSettings", config)
      .catch((error) => {
        logErrors(error, "getEasyAccessSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getControlNotifications = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/GetControlNotifications", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let response = await api
      .get("/Aludoc/Controls/GetControlNotifications", config)
      .catch((error) => {
        logErrors(error, "getControlNotifications");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getControlEmails = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/GetControlEmails", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let response = await api
      .get("/Aludoc/Controls/GetControlEmails", config)
      .catch((error) => {
        logErrors(error, "getControlEmails");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getControls = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/Get", async function (req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let response = await api
      .get("/Aludoc/Controls/Get", config)
      .catch((error) => {
        logErrors(error, "getControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const setEasyAccessSettings = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Settings/SetEasyAccessSettings", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .post("/AMSuite/Settings/SetEasyAccessSettings", data, config)
      .catch((error) => {
        logErrors(error, "setEasyAccessSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

// const setControlNotifications = app => {
//   //Ruta publica
//   app.post("/api/Aludoc/Controls/SetControlEmails", async function(
//     req,
//     res,
//     next
//   ) {
//     const data = req.body ? req.body : {};
//     let config = {
//       headers: {
//         Authorization: req.headers.authorization
//       }
//     };
//     let response = await api
//       .post("/Aludoc/Controls/SetControlEmails", data, config)
//       .catch(error => {
//         console.log("Error in setControlNotifications: ", error);
//       });
//     var cache = [];
//     res.setHeader("Content-Type", "application/json");
//     res.json(response.data);
//   });
// };

const SetControlNotificationValue = (app) => {
  const upload = multer();
  app.put(
    "/api/Aludoc/Controls/SetControlNotificationValue/:controlId/:notificationColumn/:value",
    async function (req, res, next) {
      const value = req.params.value;
      const notificationColumn = req.params.notificationColumn;
      const controlId = req.params.controlId;
      let config = {
        params: {},
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .put(
          "/Aludoc/Controls/SetControlNotificationValue/" +
            controlId +
            "/" +
            notificationColumn +
            "/" +
            value,
          {},
          config
        )
        .catch((error) => {
          console.log("Error in SetControlNotificationValue: ", error);
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const setControlEmails = (app) => {
  app.put(
    "/api/Aludoc/Controls/SetControlEmails/:controlId/:overrideEmailList",
    async function (req, res, next) {
      const controlId = req.params.controlId;
      const overrideEmailList = req.params.overrideEmailList;
      const emails = req.body;
      let config = {
        params: {},
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .put(
          "/Aludoc/Controls/SetControlEmails/" +
            controlId +
            "/" +
            overrideEmailList,
          emails,
          config
        )
        .catch((error) => {
          logErrors(error, "setControlEmails");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const getDaysUntilExpired = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Licenses/GetDaysUntilExpired", async function (
    req,
    res,
    next
  ) {
    let data = {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/AMSuite/Licenses/GetDaysUntilExpired", config)
      .catch((error) => {
        logErrors(error, "getDaysUntilExpired");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getEasyAccessSettings,
  setEasyAccessSettings,
  getControls,
  getControlNotifications,
  getControlEmails,
  setControlEmails,

  // setControlNotifications,
  SetControlNotificationValue,
  getDaysUntilExpired,
};
