const axios = require("axios");
const multer = require("multer");
var cacheServer = require("../../app_modules/cacheServer");
const fs = require("fs");
var saml2 = require("saml2-js");
const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const saveCredential = (app) => {
  //Ruta publica
  const upload = multer();
  app.post(
    "/api/AMSuite/Settings/SaveSamlCredential",
    upload.any(),
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      const dataFile = req.files[0] ? req.files[0] : undefined;

      fs.writeFile("server.pem", dataFile.buffer, function (err, buffer) {
        console.log("buffer: ", buffer);
        console.log("err: ", err);
      });

      res.sendStatus(200);
    }
  );
};

// const createMetadata = (app) => {
//   //Ruta publica
//   const upload = multer();
//   app.post(
//     "/api/AMSuite/Settings/createMetadata",
//     upload.any(),
//     async function (req, res, next) {

//       var sp_options = {
//         entity_id: "AMSuite",
//         assert_endpoint:
//           cacheServer.get("SERVER_URL") + "/AMSuite/Sessions/assert",
//         allow_unencrypted_assertion: true, //"https://sp.example.com/assert"
//       };
//       var sp = new saml2.ServiceProvider(sp_options);
//       var idp = new sp.create_metadata()
//       // const data = req.body ? req.body : {};
//       // const dataFile = req.files[0] ? req.files[0] : undefined;

//       // fs.writeFile("server.pem", dataFile.buffer, function (err, buffer) {
//       //   console.log("buffer: ", buffer);
//       //   console.log("err: ", err);
//       // });

//       res.sendStatus(200);

//     }
//   );
// };

module.exports = {
  saveCredential,
};
