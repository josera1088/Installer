const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

var LogsFunctions = require("../../app_modules/LogsFunctions");

const getRegisterVisualizations = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Users/RegistersVisualizations", async function (
    req,
    res,
    next
  ) {
    let data = {};
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .get("/AMSuite/Users/RegistersVisualizations", {})
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "RegistersVisualizations");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getUsers = (app) => {
  //Ruta publica

  app.post("/api/AMSuite/Users/Get", async function (req, res, next) {
    let currentdata = req.body ? req.body : {};

    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/Get", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "Users/Get");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getUsersAux = (app) => {
  //Ruta publica

  app.post("/api/AMSuite/Users/Get", async function (req, res, next) {
    let currentdata = req.body ? req.body : {};

    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/Get", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "Users/GetAux");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const createGroup = (app) => {
  //Ruta publica

  app.post("/api/AMSuite/Users/CreateOrUpdateUserGroup", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : {};

    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/CreateOrUpdateUserGroup", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "CreateOrUpdateUserGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getUser = (app) => {
  //Ruta publica

  app.get("/api/AMSuite/Users/Details", async function (req, res, next) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");

    let defaultData = await api
      .get("/AMSuite/Users/Details", config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getUser");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getGroups = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/GetGroups", async function (req, res, next) {
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/GetGroups", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getGroups");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const createUser = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/Create", async function (req, res, next) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/Create", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "CreateUser");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const deleteUserGroup = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/DeleteGroups", async function (req, res, next) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/DeleteGroups", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "deleteUserGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const editUser = (app) => {
  //Ruta publica
  app.put("/api/AMSuite/Users/Update", async function (req, res, next) {
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .put("/AMSuite/Users/Update", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "editUser");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const deleteUser = (app) => {
  //Ruta publica
  app.delete("/api/AMSuite/Users/Delete", async function (req, res, next) {
    let currentdata = req.query ? req.query : {};
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .delete("/AMSuite/Users/Delete", config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "deleteUser");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const getClientPermissions = (app) => {
  //Ruta publica

  app.get("/api/AMSuite/Users/Permissions", async function (req, res, next) {
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .get("/AMSuite/Users/Permissions", config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getClientPermissions");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getActiveDirectoryGroups = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/GetActiveDirectoryGroups", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/GetActiveDirectoryGroups", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getActiveDirectoryGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const CheckCredentials = (app) => {
  //Ruta publica
  app.post(
    "/api/AMSuite/Users/TestActiveDirectoryUserCredentials",
    async function (req, res, next) {
      let currentdata = req.body ? req.body : {};
      let config = {
        data: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      res.setHeader("Content-Type", "application/json");
      let defaultData = await api
        .post("/AMSuite/Users/TestActiveDirectoryUserCredentials", {}, config)
        .catch((error) => {
          LogsFunctions.logErrorsWithOutData(error, "CheckCredentials");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];

      if (defaultData) res.json(defaultData.data);
    }
  );
};

const groupDetails = (app) => {
  //Ruta publica

  app.get("/api/AMSuite/Users/GroupDetails", async function (req, res, next) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .get("/AMSuite/Users/GroupDetails", config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "groupDetails");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (defaultData) res.json(defaultData.data);
  });
};

const getAllUserActivities = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/GetAllUserActivities", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .post("/AMSuite/Users/GetAllUserActivities", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getAllUserActivities");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const createADGroups = (app) => {
  //Ruta publica
  app.post(
    "/api/AMSuite/Users/CreateSeveralActiveDirectoryUserGroups",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      res.setHeader("Content-Type", "application/json");
      let defaultData = await api
        .post(
          "/AMSuite/Users/CreateSeveralActiveDirectoryUserGroups",
          currentdata,
          config
        )
        .catch((error) => {
          LogsFunctions.logErrorsWithOutData(error, "createADGroups");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];

      if (defaultData) res.json(defaultData.data);
    }
  );
};

const updateMyUser = (app) => {
  //Ruta publica
  app.put("/api/AMSuite/Users/UpdateMyUser", async function (req, res, next) {
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    res.setHeader("Content-Type", "application/json");
    let defaultData = await api
      .put("/AMSuite/Users/UpdateMyUser", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "updateMyUser");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    if (defaultData) res.json(defaultData.data);
  });
};

const CreateSAMLGroups = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Users/CreateSAML", async function (req, res, next) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    console.log("currentdata: ", req.body);
    let currentdata = req.body ? req.body : {};
    console.log("req.headers.authorization: ", req.headers.authorization);
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let defaultData = await api
      .post("/AMSuite/Users/CreateSAMLUserGroup", currentdata, config)
      .catch((error) => {
        console.log("Error in  CreateSAMLGroups: ", error);
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

module.exports = {
  createUser,
  createGroup,
  editUser,
  getUsers,
  getGroups,
  getRegisterVisualizations,
  getUser,
  getUsersAux,
  deleteUser,
  getClientPermissions,
  getActiveDirectoryGroups,
  groupDetails,
  CheckCredentials,
  deleteUserGroup,
  createADGroups,
  updateMyUser,
  getAllUserActivities,
  CreateSAMLGroups,
};
