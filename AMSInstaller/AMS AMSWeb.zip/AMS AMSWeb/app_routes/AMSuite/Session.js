const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");
var saml2 = require("saml2-js");
var fs = require("fs");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});
const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

var LogsFunctions = require("../../app_modules/LogsFunctions");

const loginActiveDirectory = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Sessions/LoginActiveDirectory", async function (
    req,
    res,
    next
  ) {
    try {
      const login = req.body ? req.body : {};
      let data = {};
      let usedata = await api
        .post("/AMSuite/Sessions/LoginActiveDirectory", login)
        .catch((error) => {
          console.log("Error in login: ", error);
          res.status(err.response.status).json(err.response.data);
        });

      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(usedata.data);
    } catch (err) {
      LogsFunctions.logErrorsWithOutData(error, "RegistersVisualizations");
      res.status(error.response.status).send({
        errorCode: error.response.status,
        errorText: error.response.statusText,
        errorData: error.response.data.slice(0, 400),
      });
    }
  });
};

const login = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Sessions/Login", async function (req, res, next) {
    try {
      const login = req.body ? req.body : {};
      let usedata = await api
        .post("/AMSuite/Sessions/Login", login)
        .catch((error) => {
          LogsFunctions.logErrorsWithOutData(error, "RegistersVisualizations");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });

      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(usedata.data);
    } catch (error) {
      LogsFunctions.logErrorsWithOutData(error, "RegistersVisualizations");
      res.status(error.response.status).send({
        errorCode: error.response.status,
        errorText: error.response.statusText,
        errorData: error.response.data.slice(0, 400),
      });
    }
  });
};

const getCurrentUser = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Sessions/CurrentSession", async function (
    req,
    res,
    next
  ) {
    console.log("req: ", req.headers.authorization);
    let data = {};
    let token = req.headers.authorization;
    let config = {
      headers: {
        Authorization: token,
      },
    };
    let usedata = await api
      .get("/AMSuite/Sessions/CurrentSession", config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "getCurrentUser");
        res.status(error.response.status).json({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });

    if (usedata) {
      res.setHeader("Content-Type", "application/json");
      res.json(usedata.data);
    }
  });
};

const logout = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Sessions/Logout", async function (req, res, next) {
    let data = {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let usedata = await api
      .post("/AMSuite/Sessions/Logout", {}, config)
      .catch((error) => {
        LogsFunctions.logErrorsWithOutData(error, "Logout");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    if (usedata) {
      res.setHeader("Content-Type", "application/json");
      res.json(usedata.data);
    }
  });
};

const loginSAML = (app) => {
  //Ruta publica
  app.get("/api/AMSuite/Sessions/loginSAML", async function (req, res, next) {
    console.log("ENTRO LOGINSAML");
    var sp_options = {
      entity_id: "test",
      assert_endpoint:
        cacheServer.get("SERVER_URL") + "/AMSuite/Sessions/assert",
      allow_unencrypted_assertion: true, //"https://sp.example.com/assert"
    };
    var sp = new saml2.ServiceProvider(sp_options);
    var idp_options = {
      sso_login_url: cacheServer.get("urlLoginSAML"),
      certificates: [fs.readFileSync("server.pem").toString()],
    };

    var idp = new saml2.IdentityProvider(idp_options);
    console.log("ENTRO AL LOGINSAML");
    const login = req.body ? req.body : {};

    sp.create_login_request_url(idp, {}, function (err, login_url, request_id) {
      console.log("err: ", err);
      console.log("login_url: ", login_url);
      if (err != null) return res.sendStatus(500);
      res.redirect(login_url);
    });
  });
};

const metadata = (app) => {
  app.get("/api/AMSuite/Sessions/metadata", function (req, res) {
    var sp_options = {
      entity_id: "test",
      private_key: fs.readFileSync("key.pem").toString(),
      certificate: fs.readFileSync("cert.pem").toString(),
      assert_endpoint:
        cacheServer.get("SERVER_URL") + "/AMSuite/Sessions/assert",
      allow_unencrypted_assertion: true, //"https://sp.example.com/assert"
    };
    var sp = new saml2.ServiceProvider(sp_options);
    console.log("metadata", sp.create_metadata());
    res.type("application/xml");
    res.send(sp.create_metadata());
  });
};

const assertSAML = (app) => {
  //Ruta publica
  app.post("/api/AMSuite/Sessions/assert", async function (req, res, next) {
    var sp_options = {
      entity_id: "test",
      assert_endpoint:
        cacheServer.get("SERVER_URL") + "/AMSuite/Sessions/assert",
      allow_unencrypted_assertion: true, //"https://sp.example.com/assert"
    };
    var sp = new saml2.ServiceProvider(sp_options);
    var idp_options = {
      sso_login_url: cacheServer.get("urlLoginSAML"),
      certificates: [fs.readFileSync("server.pem").toString()],
    };

    var idp = new saml2.IdentityProvider(idp_options);
    var options = { request_body: req.body };
    sp.post_assert(idp, options, async function (err, saml_response) {
      console.log("err: ", err);
      if (err != null) return res.sendStatus(500);
      // let config = {
      //   headers: {
      //     Authorization: "Bearer " + cacheServer.get("userToken")
      //   }
      // };
      const user = saml_response.user.name_id;
      const attributes = saml_response.user.attributes;

      let userdata = await api
        .post("/AMSuite/Sessions/LoginSAML", { user, attributes })
        .catch((error) => {
          console.log("Error in LoginSAML: ", error);
        });
      console.log("userdata: ", userdata.data);
      let config = {
        headers: {
          Authorization: "Bearer " + userdata.data.token,
        },
      };
      if (userdata.status === 200) {
        if (
          userdata.data &&
          userdata.data.products.length > 0 &&
          Object.keys(userdata.data.permissions).length > 0
        ) {
          console.log("userdata.data: ", userdata.data);
          // res.json(userdata.data);
          console.log(
            " cacheServer ",
            cacheServer
              .get("SERVER_URL")
              .substr(0, cacheServer.get("SERVER_URL").length - 4) + "/home"
          );
          // res.send(userdata.data);
          res.redirect(
            cacheServer
              .get("SERVER_URL")
              .substr(0, cacheServer.get("SERVER_URL").length - 4) +
              // "http://localhost:3000" +
              "/home" +
              "/" +
              encodeURIComponent(userdata.data.token)
          );
        } else {
          res.redirect(
            cacheServer
              .get("SERVER_URL")
              .substr(0, cacheServer.get("SERVER_URL").length - 4) +
              "/noPermission"
          );
        }
      }
      // name_id = saml_response.user.name_id;
      // session_index = saml_response.user.session_index;
      res.setHeader("Content-Type", "application/json");
      res.sendStatus(200);
    });
  });
};

module.exports = {
  login,
  getCurrentUser,
  loginActiveDirectory,
  logout,
  loginSAML,
  assertSAML,
  metadata,
};
