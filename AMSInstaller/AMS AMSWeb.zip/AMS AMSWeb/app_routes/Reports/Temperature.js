const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const peopleInContactWithInfected = (app) => {
  //Ruta publica
  app.post("/api/Reports/PeopleInContactWithInfected", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/PeopleInContactWithInfected", data, config)
      .catch((error) => {
        logErrors(error, "PeopleInContactWithInfected");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const numericalRecordsByPeople = (app) => {
  //Ruta publica
  app.post("/api/Reports/NumericalRecordsByPeople", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/NumericalRecordsByPeople", data, config)
      .catch((error) => {
        logErrors(error, "NumericalRecordsByPeople");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const numericalRecordsByEnterprises = (app) => {
  //Ruta publica
  app.post("/api/Reports/NumericalRecordsByEnterprises", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/NumericalRecordsByEnterprises", data, config)
      .catch((error) => {
        logErrors(error, "NumericalRecordsByEnterprises");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const peopleInContactWithInfectedXLS = (app) => {
  //Ruta publica
  app.post("/api/Reports/PeopleInContactWithInfectedXLS", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/PeopleInContactWithInfectedXLS", data, config)
      .catch((error) => {
        logErrors(error, "PeopleInContactWithInfectedXLS");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const numericalRecordsByPeopleXLS = (app) => {
  //Ruta publica
  app.post("/api/Reports/NumericalRecordsByPeopleXLS", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/NumericalRecordsByPeopleXLS", data, config)
      .catch((error) => {
        logErrors(error, "NumericalRecordsByPeopleXLS");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const numericalRecordsByEnterprisesXLS = (app) => {
  //Ruta publica
  app.post("/api/Reports/NumericalRecordsByEnterprisesXLS", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/NumericalRecordsByEnterprisesXLS", data, config)
      .catch((error) => {
        logErrors(error, "NumericalRecordsByEnterprisesXLS");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  peopleInContactWithInfected,
  numericalRecordsByPeople,
  numericalRecordsByEnterprises,
  peopleInContactWithInfectedXLS,
  numericalRecordsByPeopleXLS,
  numericalRecordsByEnterprisesXLS,
};
