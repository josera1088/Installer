const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getMostOrderedProducts = (app) => {
  //Ruta publica
  app.get("/api/Reports/TikasReport/GetMostConsumedProducts", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Reports/TikasReport/GetMostConsumedProducts", config)
      .catch((error) => {
        logErrors(error, "getMostOrderedProducts");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getPeopleWithMoreOrders = (app) => {
  //Ruta publica
  app.get(
    "/api/Reports/TikasReport/GetPeopleWithMoreConsumptions",
    async function (req, res, next) {
      const data = req.query ? req.query : {};
      let config = {
        params: data,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let response = await api
        .get("/Reports/TikasReport/GetPeopleWithMoreConsumptions", config)
        .catch((error) => {
          logErrors(error, "getPeopleWithMoreOrders");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const getMonthlyOrders = (app) => {
  //Ruta publica
  app.post(
    "/api/Reports/TikasReport/GetOrdersCountForSpecificMonths",
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .post(
          "/Reports/TikasReport/GetOrdersCountForSpecificMonths",
          data,
          config
        )
        .catch((error) => {
          logErrors(error, "getMonthlyOrders");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const getAnnualOrders = (app) => {
  //Ruta publica
  app.post(
    "/api/Reports/TikasReport/GetOrdersCountForSpecificMonths",
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .post(
          "/Reports/TikasReport/GetOrdersCountForSpecificMonths",
          data,
          config
        )
        .catch((error) => {
          logErrors(error, "getAnnualOrders");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const getOrders = (app) => {
  //Ruta publica
  app.get("/api/Reports/TikasReport/GetOrders", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Reports/TikasReport/GetOrders", config)
      .catch((error) => {
        logErrors(error, "getOrders");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getMostOrderedProducts,
  getPeopleWithMoreOrders,
  getMonthlyOrders,
  getOrders,
  getAnnualOrders,
};
