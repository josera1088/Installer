const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getPrinters = (app) => {
  //Ruta publica
  app.get("/api/Tikas/Orders/GetPrinters", async function (req, res, next) {
    let data = {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Tikas/Orders/getPrinters", config)
      .catch((error) => {
        logErrors(error, "getSettings");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createPrinter = (app) => {
  app.post("/api/Tikas/Orders/CreatePrinter", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Tikas/Orders/CreatePrinter", data, config)
      .catch((error) => {
        logErrors(error, "createPrinter");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deletePrinter = (app) => {
  app.delete("/api/Tikas/Orders/DeletePrinter", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete("/Tikas/Orders/DeletePrinter", config)
      .catch((error) => {
        logErrors(error, "deletePrinter");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = { getPrinters, deletePrinter, createPrinter };
