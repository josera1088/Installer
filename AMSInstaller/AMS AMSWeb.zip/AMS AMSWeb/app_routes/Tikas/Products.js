const axios = require("axios");
const FormData = require("form-data");
const multer = require("multer");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getProducts = (app) => {
  //Ruta publica

  app.get("/api/Tikas/Products/Get", async function (req, res, next) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/Tikas/Products/Get", config)
      .catch((error) => {
        logErrors(error, "getProducts");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editProduct = (app) => {
  const upload = multer();
  app.put("/api/Tikas/Products/Update/", upload.any(), async function (
    req,
    res,
    next
  ) {
    const name = req.query && req.query.name ? req.query.name : {};
    const updateImage =
      req.query && req.query.updateImage ? req.query.updateImage : {};
    const productId =
      req.query && req.query.productId ? req.query.productId : {};
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;

    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();

    let config = {
      params: {},

      headers: {
        ...formHeaders,
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put(
        "/Tikas/Products/Update/" + productId + "/" + name + "/" + updateImage,
        formData,
        config
      )
      .catch((error) => {
        logErrors(error, "editProduct");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteProducts = (app) => {
  app.post("/api/Tikas/Products/Delete", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Tikas/Products/Delete", data, config)
      .catch((error) => {
        logErrors(error, "deleteProducts");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createProductWithImage = (app) => {
  const upload = multer();
  app.post("/api/Tikas/Products/Create", upload.any(), async function (
    req,
    res,
    next
  ) {
    const dataFile = req.files[0] ? req.files[0] : undefined;
    const name = req.query && req.query.name ? req.query.name : {};

    let formData = new FormData();
    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();
    let config = {
      params: {},
      headers: {
        ...formHeaders,
        contentType: false,
        processData: false,
        Authorization: req.headers.authorization,
      },
    };

    let response = await api
      .post("/Tikas/Products/Create" + "/" + name, formData, config)
      .catch((error) => {
        logErrors(error, "createProductWithImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getProducts,
  editProduct,
  deleteProducts,
  createProductWithImage,
};
