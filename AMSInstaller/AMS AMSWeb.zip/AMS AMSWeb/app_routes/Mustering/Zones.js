const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getZones = (app) => {
  //Ruta publica

  app.get("/api/Mustering/MusterZone/GetSafeZones", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/Mustering/MusterZone/GetSafeZones", config)
      .catch((error) => {
        logErrors(error, "getZones");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getReadersForZone = (app) => {
  //Ruta publica

  app.get("/api/Mustering/MusterReader/GetReadersForZone", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/Mustering/MusterReader/GetReadersForZone", config)
      .catch((error) => {
        logErrors(error, "getReadersForZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAllReadersAndReaderOfZone = (app) => {
  //Ruta publica

  app.get(
    "/api/Mustering/MusterReader/GetAllReadersAndReaderOfZone",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/Mustering/MusterReader/GetAllReadersAndReaderOfZone", config)
        .catch((error) => {
          logErrors(error, "getAllReadersAndReaderOfZone");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const createMusterZone = (app) => {
  app.post("/api/Mustering/MusterZone/InsertMusterZone", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Mustering/MusterZone/InsertMusterZone", data, config)
      .catch((error) => {
        logErrors(error, "createMusterZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const editReaderOfMusterZone = (app) => {
  app.put("/api/Mustering/MusterReader/EditReaderOfMusterZone", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/Mustering/MusterReader/EditReaderOfMusterZone", {}, config)
      .catch((error) => {
        logErrors(error, "editReaderOfMusterZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteAllMusterReaderByMusterZone = (app) => {
  app.delete(
    "/api/Mustering/MusterReader/DeleteAllMusterReaderByMusterZone",
    async function (req, res, next) {
      const data = req.query ? req.query : {};
      let config = {
        params: data,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let response = await api
        .delete(
          "/Mustering/MusterReader/DeleteAllMusterReaderByMusterZone",

          config
        )
        .catch((error) => {
          logErrors(error, "deleteAllMusterReaderByMusterZone");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const deleteMusterZone = (app) => {
  app.delete("/api/Mustering/MusterZone/DeleteMusterZone", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete(
        "/Mustering/MusterZone/DeleteMusterZone",

        config
      )
      .catch((error) => {
        logErrors(error, "deleteMusterZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getZones,
  getReadersForZone,
  getAllReadersAndReaderOfZone,
  createMusterZone,
  editReaderOfMusterZone,
  deleteAllMusterReaderByMusterZone,
  deleteMusterZone,
};
