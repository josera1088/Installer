const axios = require("axios");
const multer = require("multer");
const FormData = require("form-data");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000
});
const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data.slice(0, 400)}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getEmployees = app => {
  //Ruta publica

  app.post("/api/EasyAccess/Registers/GetRegisters", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Registers/GetRegisters", {}, config)
      .catch(error => {
        logErrors(error, "getEmployees");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    if (response) res.json(response.data);
  });
};

const getRegistersAnonymous = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/GetRegistersAnonymous", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS
      }
    };
    let response = await api
      .post("/EasyAccess/Registers/GetRegistersAnonymous", {}, config)
      .catch(error => {
        logErrors(error, "getRegistersAnonymous");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getHostEmployees = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/GetRegisters", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Registers/GetRegisters", data, config)
      .catch(error => {
        logErrors(error, "getHostEmployees");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getPersons = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/GetRegisters", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Registers/GetRegisters", data, config)
      .catch(error => {
        logErrors(error, "getPersons");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getTypes = app => {
  //Ruta publica
  app.get("/api/EasyAccess/Persons/GetPersonTypes", async function(
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .get("/EasyAccess/Persons/GetPersonTypes", config)
      .catch(error => {
        logErrors(error, "getTypes");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getEmployeeById = app => {
  //Ruta publica
  app.get("/api/EasyAccess/Persons/GetPersonById", async function(
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .get("/EasyAccess/Persons/GetPersonById", config)
      .catch(error => {
        logErrors(error, "getEmployeeById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createPerson = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Persons/Create", async function(req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/Create", {}, config)
      .catch(error => {
        logErrors(error, "createPerson");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createPersonAnonymous = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Persons/CreateAnonymous", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/CreateAnonymous", data, config)
      .catch(error => {
        logErrors(error, "createPersonAnonymous");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const checkDocumentNumbers = app => {
  app.post("/api/EasyAccess/Persons/CheckDocumentNumbers", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/CheckDocumentNumbers", data, config)
      .catch(error => {
        logErrors(error, "CheckDocumentNumbers");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getXLSWithVisitorGroup = app => {
  app.post("/api/EasyAccess/Persons/GetXLSWithVisitorGroup", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/GetXLSWithVisitorGroup", data, config)
      .catch(error => {
        logErrors(error, "GetXLSWithVisitorGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const setImageUrl = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Persons/SetImageUrl", async function(
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    const data2 = req.body ? req.body : {};

    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/SetImageUrl", { data2 }, config)
      .catch(error => {
        logErrors(error, "setImageUrl");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const setImage = app => {
  //Ruta publica
  const upload = multer();
  app.post("/api/EasyAccess/Persons/SetImage", upload.any(), async function(
    req,
    res,
    next
  ) {
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    const id = req.query && req.query.idString ? req.query.idString : {};

    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname
      });
    }
    const formHeaders = formData.getHeaders();
    //const dataBuffer = formData.getBuffer();

    let config = {
      params: {},
      headers: {
        ...formHeaders,
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .post("/EasyAccess/Persons/SetImage" + "/" + id, formData, config)
      .catch(error => {
        logErrors(error, "setImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const setImageAnonymous = app => {
  //Ruta publica
  const upload = multer();
  app.post(
    "/api/EasyAccess/Persons/SetImageAnonymous",
    upload.any(),
    async function(req, res, next) {
      const formData = new FormData();
      const dataFile = req.files[0];
      const id = req.query && req.query.id ? req.query.id : {};
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname
      });
      const formHeaders = formData.getHeaders();
      let config = {
        params: {},
        headers: {
          ...formHeaders,
          Authorization: "Bearer " + TOKEN_ANONYMOUS
        }
      };
      let response = await api
        .post("/EasyAccess/Persons/SetImageAnonymous/" + id, formData, config)
        .catch(error => {
          logErrors(error, "setImageAnonymous");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400)
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const updateImage = app => {
  //Ruta publica
  const upload = multer();
  app.put("/api/EasyAccess/Persons/UpdateImage", upload.any(), async function(
    req,
    res,
    next
  ) {
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    const id = req.query ? req.query.id : {};

    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname
      });
    }
    const formHeaders = formData.getHeaders();
    //const dataBuffer = formData.getBuffer();

    let config = {
      params: {},
      headers: {
        ...formHeaders,
        contentType: false,
        processData: false,
        Authorization: req.headers.authorization
      }
    };

    let response = await api
      .put("/EasyAccess/Persons/UpdateImage" + "/" + id, formData, config)
      .catch(error => {
        logErrors(error, "updateImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
  });
};

const deleteImage = app => {
  //Ruta publica
  app.delete("/api/EasyAccess/Persons/DeleteImage", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .delete("/EasyAccess/Persons/DeleteImage", config)
      .catch(error => {
        logErrors(error, "deleteImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getImage = app => {
  //Ruta publica
  app.get("/api/EasyAccess/Persons/GetImage", async function(req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .get("/EasyAccess/Persons/GetImage", config)
      .catch(error => {
        logErrors(error, "getImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createGroup = app => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/CreateGroup", async function(
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization
      }
    };
    let response = await api
      .get("/EasyAccess/Registers/CreateGroup", config)
      .catch(error => {
        logErrors(error, "createGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400)
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getPersonByDocumentNumberAnonymous = app => {
  //Ruta publica
  app.get(
    "/api/EasyAccess/Persons/GetPersonByDocumentNumberAnonymous",
    async function(req, res, next) {
      const data = req.query ? req.query : {};
      let config = {
        params: data,
        headers: {
          Authorization: "Bearer " + TOKEN_ANONYMOUS
        }
      };
      let response = await api
        .get("/EasyAccess/Persons/GetPersonByDocumentNumberAnonymous", config)
        .catch(error => {
          logErrors(error, "getPersonByDocumentNumberAnonymous");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400)
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const createVisitorGroup = app => {
  //Ruta publica
  const upload = multer();
  app.post(
    "/api/EasyAccess/Persons/CreateVisitorGroup",
    upload.any(),
    async function(req, res, next) {
      const formData = new FormData();
      const dataFile = req.files ? req.files : undefined;
      const data = req.body && req.body.Event ? req.body.Event : {};

      formData.append("Event", data);
      if (dataFile) {
        dataFile.map(file => {
          formData.append("file", file.buffer, {
            filename: file.originalname
          });
        });
      }
      const formHeaders = formData.getHeaders();

      let config = {
        params: {},
        headers: {
          ...formHeaders,
          contentType: "multipart/form-data",
          Authorization: req.headers.authorization
        }
      };
      let response = await api
        .post("/EasyAccess/Persons/CreateVisitorGroup", formData, config)
        .catch(error => {
          logErrors(error, "createDocument");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400)
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

module.exports = {
  getEmployees,
  getRegistersAnonymous,
  getPersons,
  createPerson,
  createPersonAnonymous,
  createGroup,
  getTypes,
  setImage,
  setImageUrl,
  getImage,
  deleteImage,
  updateImage,
  getEmployeeById,
  getHostEmployees,
  setImageAnonymous,
  getPersonByDocumentNumberAnonymous,
  checkDocumentNumbers,
  getXLSWithVisitorGroup,
  createVisitorGroup
};
