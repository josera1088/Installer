const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getReaders = (app) => {
  //Ruta publica
  app.get("/api/EasyAccess/Readers/GetReaders", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Readers/GetReaders", config)
      .catch((error) => {
        logErrors(error, "getReaders");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getCardFormatIds = (app) => {
  //Ruta publica
  app.get("/api/EasyAccess/Readers/GetCardFormatIds", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Readers/GetCardFormatIds", config)
      .catch((error) => {
        logErrors(error, "getCardFormatIds");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getReaders, // se va a cambiar a access control
  getCardFormatIds, //se hace en reader de access control
};
