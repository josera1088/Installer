const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});
const TOKEN_ANONYMOUS = "oITQ86J+s7vz7thJArHfTY0tDys28Z8lUNXtRchELkI=";

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getBadges = (app) => {
  //Ruta publica
  app.get("/api/EasyAccess/Badges/GetBadges", async function (req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/GetBadges", config)
      .catch((error) => {
        logErrors(error, "getBadges");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getBadgeAsQR = (app) => {
  //Ruta publica
  app.get("/api/EasyAccess/Badges/GetBadgeAsQR", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/GetBadgeAsQR", config)
      .catch((error) => {
        logErrors(error, "getBadgeAsQR");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getUnassignedBadges = (app) => {
  app.get("/api/EasyAccess/Badges/GetBadges", async function (req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: "Bearer " + TOKEN_ANONYMOUS,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/GetBadges", config)
      .catch((error) => {
        logErrors(error, "getUnassignedBadges");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getBadgeStatus = (app) => {
  app.get("/api/EasyAccess/Badges/GetBadgeTypes", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/GetBadgeTypes", config)
      .catch((error) => {
        logErrors(error, "getBadgeStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getTypes = (app) => {
  app.get("/api/EasyAccess/Badges/GetBadgeTypes", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/GetBadgeStatus", config)
      .catch((error) => {
        logErrors(error, "getTypes");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createBadgeStatus = (app) => {
  app.post("/api/EasyAccess/Badges/CreateStatus", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Badges/CreateStatus", data, config)
      .catch((error) => {
        logErrors(error, "createBadgeStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const editBadgeStatus = (app) => {
  app.put("/api/EasyAccess/Badges/EditStatus", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/EasyAccess/Badges/EditStatus", config)
      .catch((error) => {
        logErrors(error, "editBadgeStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteStatus = (app) => {
  app.delete("/api/EasyAccess/Badges/DeleteStatus", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete("/EasyAccess/Badges/DeleteStatus", config)
      .catch((error) => {
        logErrors(error, "deleteStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getCountBadgesForAutoAssign = (app) => {
  app.get("/api/EasyAccess/Badges/CountBadgesForAutoAssign", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Badges/CountBadgesForAutoAssign", config)
      .catch((error) => {
        logErrors(error, "getCountBadgesForAutoAssign");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const printBadgeData = (app) => {
  app.post("/api/EasyAccess/Badges/PrintData", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Badges/PrintData", data, config)
      .catch((error) => {
        logErrors(error, "printBadgeData");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getBadges,
  getBadgeStatus,
  getUnassignedBadges,
  getTypes,
  createBadgeStatus,
  editBadgeStatus,
  deleteStatus,
  getCountBadgesForAutoAssign,
  printBadgeData,
  getBadgeAsQR,
};
