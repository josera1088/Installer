const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

// const getRegister = app => {
//   //Ruta publica
//   app.post("/api/EasyAccess/Registers/GetRegistersAnonymous, async function(
//     req,
//     res,
//     next
//   ) {
//     console.log("llamando al servidor");
//     const data = req.body ? req.body : {};
//     let config = {
//       data: data,
//       headers: {
//         Authorization: req.headers.authorization
//       }
//     };
//     let response = await api
//       .post("/EasyAccess/Registers/GetRegisters", config)
//       .catch(error => {
//         console.log("Error in getEnterprises: ", error);
//       });
//     var cache = [];
//     res.setHeader("Content-Type", "application/json");
//     res.json(response.data);
//   });
// };

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getUserVisits = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/GetUserVisits", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Registers/GetUserVisits", data, config)
      .catch((error) => {
        logErrors(error, "getUserVisits");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createGroup = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Registers/CreateGroup", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Registers/CreateGroup", data, config)
      .catch((error) => {
        logErrors(error, "createGroup");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteRegister = (app) => {
  //Ruta publica
  app.delete("/api/EasyAccess/Registers/DeleteRegisters", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete("/EasyAccess/Registers/DeleteRegisters", config)
      .catch((error) => {
        logErrors(error, "deleteRegister");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getBadgesByRegister = (app) => {
  //Ruta publica
  app.get("/api/EasyAccess/Registers/GetBadgesByRegister", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/EasyAccess/Registers/GetBadgesByRegister", config)
      .catch((error) => {
        logErrors(error, "getBadgesByRegister");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};
module.exports = {
  // getRegister,
  getUserVisits,
  createGroup,
  deleteRegister,
  getBadgesByRegister,
};
