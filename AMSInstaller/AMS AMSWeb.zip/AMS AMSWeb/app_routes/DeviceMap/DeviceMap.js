const axios = require("axios");
const multer = require("multer");
const FormData = require("form-data");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

var LogsFunctions = require("../../app_modules/LogsFunctions");

const getPanelsPosition = (app) => {
  //Ruta publica
  app.get("/api/AccessControl/GPS/GetPanelsPosition", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/AccessControl/GPS/GetPanelsPosition", config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getSettings");
        if (error.response)
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        else res.status(500);
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getPanelsPosition,
};
