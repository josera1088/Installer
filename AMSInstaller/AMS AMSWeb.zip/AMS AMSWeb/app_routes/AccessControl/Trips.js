const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

var LogsFunctions = require("../../app_modules/LogsFunctions");


const getTrips = (app) => {
  //Ruta publica

  app.post("/api/Reports/Trip", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/Reports/Trip", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getTrips");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });

    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getBusTickets = (app) => {
  //Ruta publica

  app.post("/api/Reports/BusTickets", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let defaultData = await api
      .post("/Reports/BusTickets", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getBusTickets");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const downloadTripsXLS = (app) => {
  //Ruta publica

  app.post("/api/Reports/TripsXLS", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";

    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/TripsXLS", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "downloadTripsXLS");
        if (error.response)
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        else res, status(501).send({ errorCode: 501 });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};


const downloadTripsWithSeatsXLS = (app) => {
  //Ruta publica

  app.post("/api/Reports/TripsWithSeatsXLS", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";

    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/TripsWithSeatsXLS", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "downloadTripsWithSeatsXLS");
        if (error.response)
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        else res, status(501).send({ errorCode: 501 });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};



const downloadBusTicketsXLS = (app) => {
  //Ruta publica
  app.post("/api/Reports/BusTicketsXLS", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";

    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/BusTicketsXLS", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "downloadBusTicketsXLS");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.send(response.data);
  });
};

module.exports = {
  getTrips,
  getBusTickets,
  downloadBusTicketsXLS,
  downloadTripsXLS,
  downloadTripsWithSeatsXLS
};
