const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getVirtualZones = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/VirtualZones/GetVirtualZones", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/VirtualZones/GetVirtualZones", config)
      .catch((error) => {
        logErrors(error, "getVirtualZones");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const createVirtualZone = (app) => {
  app.post("/api/AccessControl/VirtualZones/CreateVirtualZone", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post(
        "/AccessControl/VirtualZones/CreateVirtualZone",
        currentdata,
        config
      )
      .catch((error) => {
        logErrors(error, "createVirtualZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editVirtualZone = (app) => {
  app.put("/api/AccessControl/VirtualZones/EditVirtualZone", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .put("/AccessControl/VirtualZones/EditVirtualZone", currentdata, config)
      .catch((error) => {
        logErrors(error, "editVirtualZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getVirtualZoneById = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/VirtualZones/GetVirtualZoneById", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/VirtualZones/GetVirtualZoneById", config)
      .catch((error) => {
        logErrors(error, "getVirtualZoneById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const deleteVirtualZone = (app) => {
  //Ruta publica
  app.delete(
    "/api/AccessControl/VirtualZones/DeleteVirtualZone",
    async function (req, res, next) {
      const data = req.body ? req.body : {};

      let response = await api
        .delete("/AccessControl/VirtualZones/DeleteVirtualZone", {
          data: data,
          headers: {
            Authorization: req.headers.authorization,
          },
        })
        .catch((error) => {
          logErrors(error, "deleteVirtualZone");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

module.exports = {
  getVirtualZones,
  createVirtualZone,
  editVirtualZone,
  deleteVirtualZone,
  getVirtualZoneById,
};
