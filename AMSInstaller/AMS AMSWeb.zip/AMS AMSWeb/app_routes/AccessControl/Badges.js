const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getBadgeTypes = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Badges/GetBadgeTypes", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Badges/GetBadgeTypes", config)
      .catch((error) => {
        logErrors(error, "getBadgeTypes");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getBadgeById = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Badges/GetBadgeById", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Badges/GetBadgeById", config)
      .catch((error) => {
        logErrors(error, "getBadgeById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getBadgeStatus = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Badges/GetBadgeStatus", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Badges/GetBadgeStatus", config)
      .catch((error) => {
        logErrors(error, "getBadgeStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAllBadgeStatus = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Badges/GetAllBadgeStatus", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Badges/GetAllBadgeStatus", config)
      .catch((error) => {
        logErrors(error, "getBagetAllBadgeStatusdgeStatus");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAccessLevels = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/AccessLevels/GetAccessLevels", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/AccessLevels/GetAccessLevels", config)
      .catch((error) => {
        logErrors(error, "getAccessLevels");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editBadge = (app) => {
  //Ruta publica
  app.put("/api/EasyAccess/Badges/EditBadge", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/EasyAccess/Badges/EditBadge", data, config)
      .catch((error) => {
        logErrors(error, "editBadge");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createBadge = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Badges/CreateBadge", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Badges/CreateBadge", data, config)
      .catch((error) => {
        logErrors(error, "createBadge");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createBadgeType = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Badges/CreateBadgeType", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/EasyAccess/Badges/CreateBadgeType", data, config)
      .catch((error) => {
        logErrors(error, "createBadgeType");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteBadges = (app) => {
  //Ruta publica
  app.delete("/api/EasyAccess/Badges/DeleteBadges", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};

    let response = await api
      .delete("/EasyAccess/Badges/DeleteBadges", {
        data: data,
        headers: {
          Authorization: req.headers.authorization,
        },
      })
      .catch((error) => {
        logErrors(error, "deleteBadges");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  createBadge,
  getBadgeTypes,
  getAccessLevels,
  getBadgeStatus,
  getBadgeById,
  deleteBadges,
  getAllBadgeStatus,
  editBadge,
  createBadgeType,
};
