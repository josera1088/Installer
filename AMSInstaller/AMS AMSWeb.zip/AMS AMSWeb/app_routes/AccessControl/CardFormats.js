const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getCardFormats = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/CardFormats/GetCardFormats", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/CardFormats/GetCardFormats", config)
      .catch((error) => {
        logErrors(error, "getCardFormats");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getCardFormatByID = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/CardFormats/GetCardFormatById", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/CardFormats/GetCardFormatById", config)
      .catch((error) => {
        logErrors(error, "getCardFormatByID");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editCardFormat = (app) => {
  //Ruta publica
  app.put("/api/AccessControl/CardFormats/Edit", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/AccessControl/CardFormats/Edit", data, config)
      .catch((error) => {
        logErrors(error, "editCardFormat");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const UpdateCardFormatsByReaderId = (app) => {
  //Ruta publica
  app.put(
    "/api/AccessControl/CardFormats/UpdateCardFormatsByReaderId",
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .put(
          "/AccessControl/CardFormats/UpdateCardFormatsByReaderId",
          data,
          config
        )
        .catch((error) => {
          logErrors(error, "UpdateCardFormatsByReaderId");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const createCardFormat = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/CardFormats/CreateCardFormat", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/AccessControl/CardFormats/CreateCardFormat", data, config)
      .catch((error) => {
        logErrors(error, "createCardFormat");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteCardFormat = (app) => {
  //Ruta publica
  app.delete("/api/AccessControl/CardFormats/DeleteCardFormat", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};

    let response = await api
      .delete("/AccessControl/CardFormats/DeleteCardFormat", {
        data: data,
        headers: {
          Authorization: req.headers.authorization,
        },
      })
      .catch((error) => {
        logErrors(error, "deleteCardFormat");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getCardFormatReaders = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/CardFormats/GetCardFormatReaders",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/CardFormats/GetCardFormatReaders", config)
        .catch((error) => {
          logErrors(error, "getCardFormatReaders");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const assignReaders = (app) => {
  //Ruta publica
  app.put("/api/AccessControl/CardFormats/AssignReaders", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/AccessControl/CardFormats/AssignReaders", data, config)
      .catch((error) => {
        logErrors(error, "assignReaders");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getCardFormats,
  getCardFormatByID,
  editCardFormat,
  createCardFormat,
  deleteCardFormat,
  getCardFormatReaders,
  assignReaders,
  UpdateCardFormatsByReaderId,
};
