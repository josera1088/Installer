const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getAccessLevels = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/AccessLevels/GetAccessLevels", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/AccessLevels/GetAccessLevels", config)
      .catch((error) => {
        logErrors(error, "getAccessLevels");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAccessLevel = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/AccessLevels/GetAccessLevel", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/AccessLevels/GetAccessLevel", config)
      .catch((error) => {
        logErrors(error, "getAccessLevel");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editAccessLevel = (app) => {
  //Ruta publica
  app.put("/api/AccessControl/AccessLevels/EditAccessLevel", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/AccessControl/AccessLevels/EditAccessLevel", data, config)
      .catch((error) => {
        logErrors(error, "editAccessLevel");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createAccessLevel = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/AccessLevels/CreateAccessLevel", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/AccessControl/AccessLevels/CreateAccessLevel", data, config)
      .catch((error) => {
        logErrors(error, "createAccessLevel");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteAccessLevel = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/AccessLevels/DeleteAccessLevel", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};

    let response = await api
      .post("/AccessControl/AccessLevels/DeleteAccessLevel", data, {
        headers: {
          Authorization: req.headers.authorization,
        },
      })
      .catch((error) => {
        logErrors(error, "deleteAccessLevel");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getAccessLevels,
  getAccessLevel,
  editAccessLevel,
  createAccessLevel,
  deleteAccessLevel,
};
