const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 120000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getPanels = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetPanels",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetPanels", config)
        .catch((error) => {
          logErrors(error, "getPanels");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const getRoutes = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetRoutes",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetRoutes", config)
        .catch((error) => {
          logErrors(error, "getPanels");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const logOff = (app) => {
  //Ruta publica

  app.post("/api/AccessControl/Panels/LogOff", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post(
        "/AccessControl/Panels/LogOff",
        JSON.stringify(currentdata.panelId),
        config
      )
      .catch((error) => {
        logErrors(error, "logOff");
        // res.status(error.response.status).send({
        //   errorCode: error.response.status,
        //   errorText: error.response.statusText,
        //   errorData: error.response.data.slice(0, 400),
        // });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editPanel = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/UpdateMobilePanel",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      let config = {
        data: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/UpdateMobilePanel", {}, config)
        .catch((error) => {
          logErrors(error, "editPanel");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const getPanelById = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetPanelById",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetPanelById", config)
        .catch((error) => {
          logErrors(error, "getPanelById");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const deletePanel = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/DeletePanel",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/DeletePanel", currentdata, config)
        .catch((error) => {
          logErrors(error, "deletePanel");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const createPanel = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/CreateMobilePanel",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      let config = {
        data: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/CreateMobilePanel", {}, config)
        .catch((error) => {
          logErrors(error, "createPanel");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const getMobilePanels = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetMobilePanels",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetMobilePanels", config)
        .catch((error) => {
          logErrors(error, "getMobilePanels");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};
const getWorkingModes = (app) => {
  app.get(
    "/api/AccessControl/Panels/GetWorkingModes",
    async function (req, res, next) {
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetWorkingModes", config)
        .catch((error) => {
          logErrors(error, "getWorkingModes");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const historicalTracking = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Devices/HistoricalTracking",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Devices/HistoricalTracking", config)
        .catch((error) => {
          logErrors(error, "historicalTracking");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const getReaderModes = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetReaderModes",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetReaderModes", config)
        .catch((error) => {
          logErrors(error, "getReaderModes");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const createBusCapacity = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/CreateBusCapacity",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      console.log("currentdata: ", currentdata);
      let config = {
        data: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/CreateBusCapacity", {}, config)
        .catch((error) => {
          logErrors(error, "CreateBusCapacity");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const deleteBusCapacity = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/DeleteBusCapacity",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      console.log("currentdata: ", currentdata);
      let config = {
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/DeleteBusCapacity", currentdata, config)
        .catch((error) => {
          logErrors(error, "DeleteBusCapacity");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const updateBusCapacity = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/UpdateBusCapacity",
    async function (req, res, next) {
      //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
      let currentdata = req.body ? req.body : {};
      console.log("currentdata: ", currentdata);
      let config = {
        data: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .post("/AccessControl/Panels/UpdateBusCapacity", {}, config)
        .catch((error) => {
          logErrors(error, "UpdateBusCapacity");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];

      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const getBusCapacities = (app) => {
  //Ruta publica

  app.get(
    "/api/AccessControl/Panels/GetBusCapacities",
    async function (req, res, next) {
      let currentdata = req.query ? req.query : "";
      let config = {
        params: currentdata,
        headers: {
          Authorization: req.headers.authorization,
        },
      };

      let defaultData = await api
        .get("/AccessControl/Panels/GetBusCapacities", config)
        .catch((error) => {
          logErrors(error, "GetBusCapacities");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

const createOrUpdateRoute = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/CreateOrUpdateRoute",
    async function (req, res, next) {
      let currentdata = req.body ? req.body : "";
      let config = {
        headers: {
          "Content-Type": "application/json",
          Authorization: req.headers.authorization,
        },
      };
      let defaultData = await api
        .post("/AccessControl/Panels/CreateOrUpdateRoute", currentdata, config)
        .catch((error) => {
          logErrors(error, "CreateOrUpdateRoute");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};
const deleteRoutes = (app) => {
  //Ruta publica
  app.post(
    "/api/AccessControl/Panels/DeleteRoutes",
    async function (req, res, next) {
      let currentdata = req.body ? req.body : "";
      let config = {
        headers: {
          "Content-Type": "application/json",
          Authorization: req.headers.authorization,
        },
      };
      let defaultData = await api
        .post("/AccessControl/Panels/DeleteRoutes", currentdata, config)
        .catch((error) => {
          logErrors(error, "DeleteRoutes");
          // res.status(error.response.status).send({
          //   errorCode: error.response.status,
          //   errorText: error.response.statusText,
          //   errorData: error.response.data.slice(0, 400),
          // });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(defaultData.data);
    }
  );
};

module.exports = {
  getPanels,
  logOff,
  editPanel,
  getPanelById,
  deletePanel,
  createPanel,
  getMobilePanels,
  historicalTracking,
  getReaderModes,
  getRoutes,
  getWorkingModes,
  createBusCapacity,
  getBusCapacities,
  deleteBusCapacity,
  updateBusCapacity,
  deleteRoutes,
  createOrUpdateRoute,
};