const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getImeis = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/Devices/GetIMEIs", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/Devices/GetIMEIs", config)
      .catch((error) => {
        logErrors(error, "getImeis");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editImei = (app) => {
  //Ruta publica

  app.post("/api/AccessControl/Devices/UpdateIMEI", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        ContentType: "application/json",
        Authorization: req.headers.authorization,
      },
    };
    let defaultData = await api
      .post("/AccessControl/Devices/UpdateIMEI", currentdata, config)
      .catch((error) => {
        logErrors(error, "editImei");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const createImei = (app) => {
  //Ruta publica

  app.post("/api/AccessControl/Devices/CreateIMEI", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        ContentType: "application/json",
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/AccessControl/Devices/CreateIMEI", currentdata, config)
      .catch((error) => {
        logErrors(error, "createImei");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const deleteImei = (app) => {
  //Ruta publica

  app.post("/api/AccessControl/Devices/DeleteIMEI", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/AccessControl/Devices/DeleteIMEI", currentdata, config)
      .catch((error) => {
        logErrors(error, "deleteImei");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

module.exports = { getImeis, editImei, createImei, deleteImei };
