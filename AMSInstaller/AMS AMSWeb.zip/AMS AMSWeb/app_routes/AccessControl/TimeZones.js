const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getTimeZones = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/TimeZone/GetTimeZones", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/TimeZone/GetTimeZones", config)
      .catch((error) => {
        logErrors(error, "getTimeZones");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getTimeZoneById = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/TimeZone/GetTimeZoneById", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/TimeZone/GetTimeZoneById", config)
      .catch((error) => {
        logErrors(error, "getTimeZoneById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const createTimeZone = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/TimeZone/CreateTimeZone", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/AccessControl/TimeZone/CreateTimeZone", {}, config)
      .catch((error) => {
        logErrors(error, "createTimeZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editTimeZone = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/TimeZone/EditTimeZone", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/AccessControl/TimeZone/EditTimeZone", {}, config)
      .catch((error) => {
        logErrors(error, "editTimeZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const deleteTimeZone = (app) => {
  //Ruta publica
  app.post("/api/AccessControl/TimeZone/DeleteTimeZone", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      // data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/AccessControl/TimeZone/DeleteTimeZone", currentdata, config)
      .catch((error) => {
        logErrors(error, "deleteTimeZone");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

module.exports = {
  getTimeZones,
  createTimeZone,
  getTimeZoneById,
  editTimeZone,
  deleteTimeZone,
};
