const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");
var LogsFunctions = require("../../app_modules/LogsFunctions");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getEventMonitoring = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/EventsMonitor/GetEvents", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/EventsMonitor/GetEvents", config)
      .catch((error) => {
        logErrors(error, "getEventMonitoring");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getEventsReport = (app) => {
  //Ruta publica

  app.post("/api/Reports/Events", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/Reports/Events", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getEventsReport");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });

    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getEventsXLS = (app) => {
  //Ruta publica
  app.post("/api/Reports/EventsXLS", async function (req, res, next) {
    let currentdata = req.body ? req.body : "";

    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Reports/EventsXLS", currentdata, config)
      .catch((error) => {
        LogsFunctions.logErrors(error, "getEventsXLS");
        if (error.response)
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        else res, status(501).send({ errorCode: 501 });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getEventById = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/EventsMonitor/GetEventById", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/EventsMonitor/GetEventById", config)
      .catch((error) => {
        logErrors(error, "getEventById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getPersonImage = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/EventsMonitor/GetPersonImage", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/EventsMonitor/GetPersonImage", config)
      .catch((error) => {
        logErrors(error, "getPersonImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAccessImage = (app) => {
  //Ruta publica

  app.get("/api/AccessControl/EventsMonitor/GetAccessImage", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/AccessControl/EventsMonitor/GetAccessImage", config)
      .catch((error) => {
        logErrors(error, "getAccessImage");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

module.exports = {
  getEventMonitoring,
  getEventById,
  getPersonImage,
  getAccessImage,
  getEventsReport,
  getEventsXLS,
};
