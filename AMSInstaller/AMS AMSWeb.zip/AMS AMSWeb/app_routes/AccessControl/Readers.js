const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getReaders = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetReaders", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetReaders", config)
      .catch((error) => {
        logErrors(error, "getReaders");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getVirtualReaders = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetVirtualReaders", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetVirtualReaders", config)
      .catch((error) => {
        logErrors(error, "getVirtualReaders");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const createReader = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Readers/CreateReader", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/EasyAccess/Readers/CreateReader", {}, config)
      .catch((error) => {
        logErrors(error, "createReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const editReader = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Readers/EditReader", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      data: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/EasyAccess/Readers/EditReader", {}, config)
      .catch((error) => {
        logErrors(error, "editReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getDeviceReader = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetDeviceReader", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetDeviceReader", config)
      .catch((error) => {
        logErrors(error, "getDeviceReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getVirtualReadersByPanel = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetVirtualReadersByPanel", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetVirtualReadersByPanel", config)
      .catch((error) => {
        logErrors(error, "getVirtualReadersByPanel");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const deleteReader = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Readers/DeleteReader", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/EasyAccess/Readers/DeleteReader", currentdata, config)
      .catch((error) => {
        logErrors(error, "deleteReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const assignAccessLevels = (app) => {
  //Ruta publica
  app.post("/api/EasyAccess/Readers/AssignAccessLevel", async function (
    req,
    res,
    next
  ) {
    //let data = req.body ? (req.body.params ? req.body.params.data : {}) : {};
    let currentdata = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .post("/EasyAccess/Readers/AssignAccessLevel", currentdata, config)
      .catch((error) => {
        logErrors(error, "assignAccessLevels");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];

    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getExitReader = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetExitReaders", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetExitReaders", config)
      .catch((error) => {
        logErrors(error, "getExitReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getEntranceReader = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetEntranceReaders", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetEntranceReaders", config)
      .catch((error) => {
        logErrors(error, "getEntranceReader");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getAccessLevels = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetAccessLevelsList", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetAccessLevelsList", config)
      .catch((error) => {
        logErrors(error, "getAccessLevels");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const getCardFormatIds = (app) => {
  //Ruta publica

  app.get("/api/EasyAccess/Readers/GetCardFormatIds", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };

    let defaultData = await api
      .get("/EasyAccess/Readers/GetCardFormatIds", config)
      .catch((error) => {
        logErrors(error, "getCardFormatIds");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

const checkReaderName = (app) => {
  app.get("/api/EasyAccess/Readers/CheckReaderName", async function (
    req,
    res,
    next
  ) {
    let currentdata = req.query ? req.query : "";
    let config = {
      params: currentdata,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let defaultData = await api
      .get("/EasyAccess/Readers/CheckReaderName", config)
      .catch((error) => {
        logErrors(error, "checkReaderName");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(defaultData.data);
  });
};

module.exports = {
  getReaders,
  getVirtualReaders,
  createReader,
  editReader,
  getDeviceReader,
  getVirtualReadersByPanel,
  deleteReader,
  getEntranceReader,
  getExitReader,
  // getTypes,
  assignAccessLevels,
  getAccessLevels,
  getCardFormatIds,
  checkReaderName,
};
