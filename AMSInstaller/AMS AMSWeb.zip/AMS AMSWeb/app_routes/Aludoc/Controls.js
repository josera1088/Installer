const axios = require("axios");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getMyControls = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/Get", async function (req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/Get", config)
      .catch((error) => {
        logErrors(error, "getMyControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getHighestControlId = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/getHighestControlId", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/getHighestControlId", config)
      .catch((error) => {
        logErrors(error, "getHighestControlId");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const createControl = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Controls/Create", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Controls/Create", data, config)
      .catch((error) => {
        logErrors(error, "createControl");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const editControl = (app) => {
  //Ruta publica
  app.put("/api/Aludoc/Controls/Edit", async function (req, res, next) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put("/Aludoc/Controls/Edit", data, config)
      .catch((error) => {
        logErrors(error, "editControl");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getDetailsControl = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/Details", async function (req, res, next) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/Details", config)
      .catch((error) => {
        logErrors(error, "getDetailsControl");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const deleteControls = (app) => {
  //Ruta publica
  app.delete("/api/Aludoc/Controls/DeleteControls", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete("/Aludoc/Controls/DeleteControls", config)
      .catch((error) => {
        logErrors(error, "deleteControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const setControlNotifications = (app) => {
  //Ruta publica
  app.put("/api/Aludoc/Controls/SetControlNotifications", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    const id = req.query ? req.query : {};
    let config = {
      params: id,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .put(
        "/Aludoc/Controls/SetControlNotifications/" + data.controlId,
        data,
        config
      )
      .catch((error) => {
        logErrors(error, "setControlNotifications");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getPersonDocumentationStatusByControls = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/GetPeopleByControlId", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/GetPeopleByControlId", config)
      .catch((error) => {
        logErrors(error, "getPersonDocumentationStatusByControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response)
      if (response) {
        res.setHeader("Content-Type", "application/json");
        res.json(response.data);
      }
  });
};

const getPersonsByControl = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/GetPeopleByControlId", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/GetPeopleByControlId", config)
      .catch((error) => {
        logErrors(error, "getPersonsByControl");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getControlPeopleGraphData = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/ControlPeopleGraphData", async function (
    req,
    res,
    next
  ) {
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/ControlPeopleGraphData", config)
      .catch((error) => {
        logErrors(error, "getControlPeopleGraphData");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

const getCompaniesByControlId = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Controls/GetCompaniesByControlId", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Controls/GetCompaniesByControlId", config)
      .catch((error) => {
        logErrors(error, "getCompaniesByControlId");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    if (response) {
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  });
};

module.exports = {
  getMyControls,
  createControl,
  editControl,
  getDetailsControl,
  deleteControls,
  getHighestControlId,
  setControlNotifications,
  getCompaniesByControlId,
  getPersonDocumentationStatusByControls,
  getPersonsByControl,
  getControlPeopleGraphData,
};
