const axios = require("axios");
const multer = require("multer");
const FormData = require("form-data");
var cacheServer = require("../../app_modules/cacheServer");

const api = axios.create({
  baseURL: cacheServer.get("API_URL"), //"http://192.168.1.41:62722/api",
  timeout: 30000,
});

const logErrors = (error, method) => {
  console.log(`ERROR EN ${method}`);
  console.log("       Sended Data       ");
  console.log("    -----------------    ");
  console.log(`url: ${error.response.config.url}`);
  console.log(`method: ${error.response.config.method}`);
  console.log(`data: ${error.response.config.data.slice(0, 400)}`);
  console.log("_________________________");
  console.log("      Received Data      ");
  console.log("    -----------------    ");
  console.log(`status: ${error.response.status}`);
  console.log(`status Text: ${error.response.statusText}`);
  console.log(`data Error: ${error.response.data.slice(0, 400)}`);
};

const getDocuments = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetAllDocument", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/GetAllDocument", config)
      .catch((error) => {
        logErrors(error, "getMyControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentTypesByCompanies = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/GetDocumentTypesByCompanies", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/GetDocumentTypesByCompanies", {}, config)
      .catch((error) => {
        logErrors(error, "getMyControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentById = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetDocumentById", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/GetDocumentById", config)
      .catch((error) => {
        logErrors(error, "getMyControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentsExpiringBeforeDate = (app) => {
  //Ruta publica
  app.post(
    "/api/Aludoc/Document/GetDocumentsExpiringBeforeDate",
    async function (req, res, next) {
      const data = req.body ? req.body : {};
      let config = {
        data: data,
        headers: {
          Authorization: req.headers.authorization,
        },
      };
      let response = await api
        .post("/Aludoc/Document/GetDocumentsExpiringBeforeDate", {}, config)
        .catch((error) => {
          logErrors(error, "getMyControls");
          res.status(error.response.status).send({
            errorCode: error.response.status,
            errorText: error.response.statusText,
            errorData: error.response.data.slice(0, 400),
          });
        });
      var cache = [];
      res.setHeader("Content-Type", "application/json");
      res.json(response.data);
    }
  );
};

const getAllDocumentsByEnterprises = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetDocumentsByCompanies", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/GetDocumentsByCompanies", data, config)
      .catch((error) => {
        logErrors(error, "getMyControls");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    if (response) res.json(response.data);
  });
};

const getDocumentTypes = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetAllDocumentType", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/GetAllDocumentType", data, config)
      .catch((error) => {
        logErrors(error, "getDocumentTypes");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentByEnterprise = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetDocumentByEnterprise", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/GetDocumentByEnterprise", config)
      .catch((error) => {
        logErrors(error, "getDocumentByEnterprise");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentFiles = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetDocumentFiles", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/GetDocumentFiles", config)
      .catch((error) => {
        logErrors(error, "getDocumentFiles");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const downloadDocumentFile = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/DownloadDocumentFileContent", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        ContentType: "application/octet-stream",
        ContentDisposition: "attachment",
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/DownloadDocumentFileContent", config)
      .catch((error) => {
        logErrors(error, "downloadDocumentFile");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentTypeById = (app) => {
  //Ruta publica
  app.get("/api/Aludoc/Document/GetAllDocumentTypeById", async function (
    req,
    res,
    next
  ) {
    const data = req.query ? req.query : {};
    let config = {
      params: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .get("/Aludoc/Document/GetAllDocumentTypeById", config)
      .catch((error) => {
        logErrors(error, "getDocumentTypeById");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const getDocumentStatusGraphData = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/GetDocumentStatusGraphData", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/GetDocumentStatusGraphData", data, config)
      .catch((error) => {
        logErrors(error, "getDocumentStatusGraphData");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createDocument = (app) => {
  //Ruta publica
  const upload = multer();
  app.post("/api/Aludoc/Document/CreateDocument", upload.any(), async function (
    req,
    res,
    next
  ) {
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    const data = req.body && req.body.document ? req.body.document : {};

    formData.append("document", data);
    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();

    let config = {
      params: {},
      headers: {
        ...formHeaders,
        contentType: "multipart/form-data",
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/CreateDocument", formData, config)
      .catch((error) => {
        logErrors(error, "createDocument");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const editDocument = (app) => {
  //Ruta publica
  const upload = multer();
  app.post("/api/Aludoc/Document/EditDocument", upload.any(), async function (
    req,
    res,
    next
  ) {
    const formData = new FormData();
    const dataFile = req.files[0] ? req.files[0] : undefined;
    const data = req.body && req.body.document ? req.body.document : {};

    formData.append("document", data);
    if (dataFile) {
      formData.append("file", dataFile.buffer, {
        filename: dataFile.originalname,
      });
    }
    const formHeaders = formData.getHeaders();

    let config = {
      params: {},
      headers: {
        ...formHeaders,
        contentType: "multipart/form-data",
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/EditDocument", formData, config)
      .catch((error) => {
        logErrors(error, "editDocument");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const createDocumentType = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/CreateDocumentType", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/CreateDocumentType", data, config)
      .catch((error) => {
        logErrors(error, "createDocumentType");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const editDocumentType = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/EditDocumentType", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/EditDocumentType", data, config)
      .catch((error) => {
        logErrors(error, "editDocumentType");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteDocuments = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/DeleteDocuments", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .post("/Aludoc/Document/DeleteDocuments", data, config)
      .catch((error) => {
        logErrors(error, "deleteDocuments");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const deleteDocumentsType = (app) => {
  //Ruta publica
  app.delete("/api/Aludoc/Document/DeleteDocumentType", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};
    let config = {
      data: data,
      headers: {
        Authorization: req.headers.authorization,
      },
    };
    let response = await api
      .delete("/Aludoc/Document/DeleteDocumentType", config)
      .catch((error) => {
        logErrors(error, "deleteDocumentsType");
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    var cache = [];
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

const genericDataTableApiCall = (app) => {
  //Ruta publica
  app.post("/api/Aludoc/Document/GenericDataTableApiCall", async function (
    req,
    res,
    next
  ) {
    const data = req.body ? req.body : {};

    const { url, method, ...dataTable } = data;
    const dataOrParams = ["GET", "DELETE"].includes(method) ? "params" : "data";

    let response = await api
      .request({
        url,
        method,
        headers: {
          Authorization: req.headers.authorization,
        },
        [dataOrParams]: dataTable,
      })
      .catch((error) => {
        logErrors(error, url);
        res.status(error.response.status).send({
          errorCode: error.response.status,
          errorText: error.response.statusText,
          errorData: error.response.data.slice(0, 400),
        });
      });
    res.setHeader("Content-Type", "application/json");
    res.json(response.data);
  });
};

module.exports = {
  getDocumentTypes,
  getDocumentById,
  createDocument,
  editDocument,
  getDocumentByEnterprise,
  deleteDocuments,
  createDocumentType,
  deleteDocumentsType,
  getDocumentTypeById,
  getDocuments,
  editDocumentType,
  getDocumentFiles,
  downloadDocumentFile,
  getDocumentsExpiringBeforeDate,
  getAllDocumentsByEnterprises,
  getDocumentTypesByCompanies,
  getDocumentStatusGraphData,
  genericDataTableApiCall,
};
